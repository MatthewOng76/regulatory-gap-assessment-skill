Regulatory Gap Assessment Skill package

Contents:
- Skill.md
- examples/prompt-start-new-analysis.txt
- examples/prompt-add-internal-standard.txt

Suggested usage:
- Make Skill.md available to your Co-pilot or agent.
- Keep the Excel workbook open.
- Provide the regulation paper and internal policy/standard documents in the same working context.
